<?php
/**
 * Marketplace block for fieldset of configurable product
 */
namespace Webkul\Marketplace\Block\Product\Steps;

use Magento\ConfigurableProduct\Model\Product\VariationMediaAttributes;

class Bulk extends \Magento\Ui\Block\Component\StepsWizard\StepAbstract
{
    /**
     * @var \Magento\ConfigurableProduct\Model\Product\VariationMediaAttributes
     */
    protected $_confVariationMediaAttributes;

    /**
    * @var \Magento\Catalog\Helper\Image 
    */
    protected $_helperImage;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param VariationMediaAttributes $confVariationMediaAttributes
     * @param \Magento\Catalog\Helper\Image $helperImage
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        VariationMediaAttributes $confVariationMediaAttributes,
        \Magento\Catalog\Helper\Image $helperImage
    ) 
    {
        parent::__construct($context);
        $this->_confVariationMediaAttributes = $confVariationMediaAttributes;
        $this->_helperImage = $helperImage;
    }

    public function getCaption()
    {
        return __('Bulk Images &amp; Price');
    }

    public function getConfMediaAttributes()
    {
        return $this->_confVariationMediaAttributes->getMediaAttributes();
    }

    /**
     * @return string
     */
    public function getPlaceholderImageUrl()
    {
        return $this->_helperImage->getDefaultPlaceholderUrl('thumbnail');
    }

    /**
     * @return array
     */
    public function getAttributeImageTypes()
    {
        $attrImageTypes = [];
        foreach ($this->_confVariationMediaAttributes->getMediaAttributes() as $attribute) {
            $attrImageTypes[$attribute->getAttributeCode()] = [
                'code' => $attribute->getAttributeCode(),
                'name' => '',
                'value' => '',
            ];
        }
        return $attrImageTypes;
    }
}
