<?php
namespace Webkul\Marketplace\Block;
class Sellerregistration extends \Magento\Framework\View\Element\Template
  {
    public function _prepareLayout(){
       return parent::_prepareLayout();
    }
}
