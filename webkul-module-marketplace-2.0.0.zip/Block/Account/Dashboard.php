<?php
namespace Webkul\Marketplace\Block\Account;
/**
 * Webkul Marketplace Account Dashboard Block
 *
 * @category    Webkul
 * @package     Webkul_Marketplace
 * @author      Webkul Software Private Limited
 *
 */
use Magento\Sales\Model\Order;
use Magento\Customer\Model\Customer;

class Dashboard extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Customer\Model\Customer
     */
    protected $customer;

    /**
     * @var \Magento\Sales\Model\Order
     */
    protected $order;

    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @var Session
     */
    protected $customerSession;

    /**
    * @param Context $context
    * @param array $data
    * @param Customer $customer
    * @param Order $order
    * @param \Magento\Framework\ObjectManagerInterface $objectManager
    * @param \Magento\Customer\Model\Session $customerSession
    */
    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectManager,
        Order $order,
        Customer $customer,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = []
    ) {
        $this->Customer = $customer;
        $this->Order = $order;
        $this->_objectManager = $objectManager;
        $this->_customerSession = $customerSession;
        parent::__construct($context, $data);
    }


    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->pageConfig->getTitle()->set(__('Seller Dashboard'));
    }

    public function getCustomerId()
    {
        return $this->_customerSession->getCustomerId();
    }

    /**
     * @return bool|\Webkul\Marketplace\Model\ResourceModel\Saleslist\Collection
     */

    public function getCollection()
    {
        if (!($customerId = $this->getCustomerId())) {
            return false;
        }

        $ids = array();
        $orderids = array();
        $filter_orderid = '';
        $filter_orderstatus = '';
        $filter_data_to = '';
        $filter_data_frm = '';
        $from = null;
        $to = null;

        if(isset($_GET['s'])){
            $filter_orderid = $_GET['s'] != ""?$_GET['s']:"";
        }
        if(isset($_GET['orderstatus'])){
            $filter_orderstatus = $_GET['orderstatus'] != ""?$_GET['orderstatus']:"";
        }
        if(isset($_GET['from_date'])){
            $filter_data_frm = $_GET['from_date'] != ""?$_GET['from_date']:"";
        }
        if(isset($_GET['to_date'])){
            $filter_data_to = $_GET['to_date'] != ""?$_GET['to_date']:"";
        }

        $collection_orders = $this->_objectManager->create('Webkul\Marketplace\Model\Saleslist')
                            ->getCollection()
                            ->addFieldToFilter(
                                'seller_id',
                                ['eq' => $customerId]
                            )
                            ->addFieldToSelect('order_id')
                            ->distinct(true);
        foreach ($collection_orders as $collection_order) {       
            if($filter_orderstatus){
                $tracking=$this->_objectManager->create('Webkul\Marketplace\Helper\Orders')->getOrderinfo($collection_order->getOrderId());
                if($tracking){
                    if($tracking->getIsCanceled()){
                        if($filter_orderstatus=='canceled'){
                            array_push($orderids, $collection_order->getOrderId());
                        }
                    }else{
                        $tracking = $this->_objectManager->create('Magento\Sales\Model\Order')->load($collection_order->getOrderId());                
                        if($tracking->getStatus()==$filter_orderstatus){
                            array_push($orderids, $collection_order->getOrderId());
                        }
                    }
                }
            }else{
                array_push($orderids, $collection_order->getOrderId());
            }
        }

        foreach ($orderids as $orderid) {
            $collection_ids = $this->_objectManager->create('Webkul\Marketplace\Model\Saleslist')
                            ->getCollection()
                            ->addFieldToFilter(
                                'order_id',
                                ['eq' => $orderid]
                            )
                            ->setOrder('entity_id','DESC')
                            ->setPageSize(1);
            foreach ($collection_ids as $collection_id) {
                $autoid = $collection_id->getId();                
                array_push($ids, $autoid);
            }
        }

        $collection = $this->_objectManager->create('Webkul\Marketplace\Model\Saleslist')
        ->getCollection()
        ->addFieldToFilter(
            'entity_id',
            ['in' => $ids]
        );

        if($filter_data_to){
            $todate = date_create($filter_data_to);
            $to = date_format($todate, 'Y-m-d 23:59:59');
        }
        if($filter_data_frm){
            $fromdate = date_create($filter_data_frm);
            $from = date_format($fromdate, 'Y-m-d H:i:s');
        }

        if($filter_orderid){
            $collection->addFieldToFilter(
                'magerealorder_id',
                ['eq' => $filter_orderid]
            );
        }

        $collection->addFieldToFilter(
            'created_at',
            ['datetime' => true,'from' => $from,'to' =>  $to]
        ); 

        $collection->setOrder(
            'created_at',
            'desc'
        );
        return $collection;
    }

    /**
     * @return $this
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();
    }

    public function getDateDetail()
    { 
        $seller_id = $this->getCustomerId();

        $collection = $this->_objectManager->create('Webkul\Marketplace\Model\Saleslist')
                            ->getCollection()
                            ->addFieldToFilter(
                                'seller_id',
                                ['eq' => $seller_id]
                            )
                            ->addFieldToFilter(
                                'order_id',
                                ['neq' => 0]
                            );
        $collection1 = $this->_objectManager->create('Webkul\Marketplace\Model\Saleslist')
                            ->getCollection()
                            ->addFieldToFilter(
                                'seller_id',
                                ['eq' => $seller_id]
                            )
                            ->addFieldToFilter(
                                'order_id',
                                ['neq' => 0]
                            );
        $collection2 = $this->_objectManager->create('Webkul\Marketplace\Model\Saleslist')
                            ->getCollection()
                            ->addFieldToFilter(
                                'seller_id',
                                ['eq' => $seller_id]
                            )
                            ->addFieldToFilter(
                                'order_id',
                                ['neq' => 0]
                            );
        $collection3 = $this->_objectManager->create('Webkul\Marketplace\Model\Saleslist')
                            ->getCollection()
                            ->addFieldToFilter(
                                'seller_id',
                                ['eq' => $seller_id]
                            )
                            ->addFieldToFilter(
                                'order_id',
                                ['neq' => 0]
                            );

        $first_day_of_week = date('Y-m-d', strtotime('Last Monday', time()));

        $last_day_of_week = date('Y-m-d', strtotime('Next Sunday', time()));

        $month=$collection1->addFieldToFilter('created_at', array('datetime' => true,'from' =>  date('Y-m').'-01 00:00:00','to' =>  date('Y-m').'-31 23:59:59'));

        $week=$collection2->addFieldToFilter('created_at', array('datetime' => true,'from' =>  $first_day_of_week.' 00:00:00','to' =>  $last_day_of_week.' 23:59:59'));

        $day=$collection3->addFieldToFilter('created_at', array('datetime' => true,'from' =>  date('Y-m-d').' 00:00:00','to' =>  date('Y-m-d').' 23:59:59'));

        $sale=0;

        $data1['year']=$sale;

        $sale1=0;
        foreach($day as $record1) {
            $sale1=$sale1+$record1->getActualSellerAmount();
        }
        $data1['day']=$sale1;

        $sale2=0;
        foreach($month as $record2) {
            $sale2=$sale2+$record2->getActualSellerAmount();
        }
        $data1['month']=$sale2;

        $sale3=0;
        foreach($week as $record3) {
            $sale3=$sale3+$record3->getActualSellerAmount();
        }
        $data1['week']=$sale3;

        $temp=0;
        foreach ($collection as $record) {
            $temp = $temp+$record->getActualSellerAmount();
        }
        $data1['totalamount']=$temp;
        return $data1;
    }

    public function getpronamebyorder($order_id)
    {
        $seller_id = $this->getCustomerId();
        $collection = $this->_objectManager->create('Webkul\Marketplace\Model\Saleslist')
                            ->getCollection()
                            ->addFieldToFilter(
                                'seller_id',
                                ['eq' => $seller_id]
                            )
                            ->addFieldToFilter(
                                'order_id',
                                ['eq' => $order_id]
                            );
        $name='';
        foreach($collection as $res){
            $products = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($res['mageproduct_id']);
            $name .= "<p style='float:left;'><a href='".$products->getProductUrl()."' target='blank'>".$res['magepro_name']."</a> X ".intval($res['magequantity'])."&nbsp;</p>";
        }   
        return $name;       
    }

    public function getPricebyorder($order_id)
    {
        $seller_id = $this->getCustomerId();
        $collection = $this->_objectManager->create('Webkul\Marketplace\Model\Saleslist')
                    ->getCollection();
        $name='';
        $collection->getSelect()
                    ->where('seller_id ='.$seller_id)
                    ->columns('SUM(actual_seller_amount) AS qty')
                    ->group('order_id');     
        foreach($collection as $coll){
            if($coll->getOrderId() == $order_id){
                return $coll->getQty();
            }
        }
    }

    public function getTotalSaleColl($value='')
    {
        $seller_id = $this->getCustomerId();

        $collection = $this->_objectManager->create('Webkul\Marketplace\Model\Saleperpartner')
        ->getCollection()
        ->addFieldToFilter(
            'seller_id',
            ['eq' => $seller_id]
        );
        return $collection;
    }

    public function getCurrentUrl()
    {
        return $this->_urlBuilder->getCurrentUrl(); // Give the current url of recently viewed page
    }

    public function getReviewcollection($value='')
    {
        $seller_id = $this->getCustomerId();

        $collection = $this->_objectManager->create('Webkul\Marketplace\Model\Feedback')
        ->getCollection()
        ->addFieldToFilter(
            'seller_id',
            ['eq' => $seller_id]
        )
        ->addFieldToFilter(
            'status',
            ['eq' => 1]
        )
        ->setOrder(
            'created_at',
            'desc'
        )
        ->setPageSize(5)
        ->setCurPage(1);

        return $collection;
    }
}
