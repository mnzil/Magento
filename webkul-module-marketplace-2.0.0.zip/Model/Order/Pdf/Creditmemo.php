<?php
namespace Webkul\Marketplace\Model\Order\Pdf;

use Magento\Customer\Model\Session;

use Magento\Payment\Helper\Data as PaymentHelperData;
use Magento\Framework\Stdlib\StringUtils as StringUtils;
use Magento\Framework\App\Config\ScopeConfigInterface as ScopeConfigInterface;
use Magento\Framework\Filesystem as Filesystem;
use Magento\Sales\Model\Order\Pdf\Config as PdfConfig;
use Magento\Sales\Model\Order\Pdf\Total\Factory as PdfTotalFactory;
use Magento\Sales\Model\Order\Pdf\ItemsFactory as PdfItemsFactory;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface as TimezoneInterface;
use Magento\Framework\Translate\Inline\StateInterface as StateInterface;
use Magento\Sales\Model\Order\Address\Renderer as AddressRenderer;
use Magento\Store\Model\StoreManagerInterface as StoreManagerInterface;
use Magento\Framework\Locale\ResolverInterface as ResolverInterface;

/**
 * Marketplace Order Creditmemo PDF model
 */
class Creditmemo extends \Magento\Sales\Model\Order\Pdf\AbstractPdf
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @param PaymentHelperData $paymentData
     * @param StringUtils $string
     * @param ScopeConfigInterface $scopeConfig
     * @param Filesystem $filesystem
     * @param PdfConfig $sellerPdfConfig
     * @param PdfTotalFactory $sellerPdfTotalFactory
     * @param PdfItemsFactory $sellerPdfItemsFactory
     * @param TimezoneInterface $localeDate
     * @param StateInterface $inlineTranslation
     * @param AddressRenderer $addressRenderer
     * @param StoreManagerInterface $storeManager
     * @param ResolverInterface $localeResolver
     * @param array $data
     */
    public function __construct(
        Session $customerSession,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        PaymentHelperData $paymentHelperData,
        StringUtils $stringUtils,
        ScopeConfigInterface $scopeConfigInterface,
        Filesystem $filesystem,
        PdfConfig $sellerPdfConfig,
        PdfTotalFactory $sellerPdfTotalFactory,
        PdfItemsFactory $sellerPdfItemsFactory,
        TimezoneInterface $timezoneInterface,
        StateInterface $inlineTranslation,
        AddressRenderer $addressRenderer,
        StoreManagerInterface $storeManager,
        ResolverInterface $resolverInterface,
        array $data = []
    ) 
    {
        $this->_customerSession = $customerSession;
        $this->_objectManager = $objectManager;
        $this->_storeManager = $storeManager;
        $this->_localeResolver = $resolverInterface;
        parent::__construct(
            $paymentHelperData,
            $stringUtils,
            $scopeConfigInterface,
            $filesystem,
            $sellerPdfConfig,
            $sellerPdfTotalFactory,
            $sellerPdfItemsFactory,
            $timezoneInterface,
            $inlineTranslation,
            $addressRenderer,
            $data
        );
    }

    /**
     * Retrieve customer session object
     *
     * @return \Magento\Customer\Model\Session
     */
    protected function _getSession()
    {
        return $this->_customerSession;
    }

    /**
     * Return PDF document
     *
     * @param  array $sellerCreditmemos
     * @return \Zend_Pdf
     */
    public function getPdf($sellerCreditmemos = [])
    {
        $this->_beforeGetPdf();
        $this->_initRenderer('creditmemo');
        $sellerPdf = new \Zend_Pdf();
        $this->_setPdf($sellerPdf);
        $style = new \Zend_Pdf_Style();
        $this->_setFontBold($style, 10);
        foreach ($sellerCreditmemos as $sellerCreditmemo) {
            if ($sellerCreditmemo->getStoreId()) {
                $this->_localeResolver->emulate($sellerCreditmemo->getStoreId());
                $this->_storeManager->setCurrentStore($sellerCreditmemo->getStoreId());
            }
            $sellerPdfPage = $this->newSellerPage();
            $sellerOrder = $sellerCreditmemo->getOrder();
            /* Add seller logo image if exist*/
            $this->insertLogo($sellerPdfPage, $sellerCreditmemo->getStore());
            /* Add seller address and other informations like vat,tax*/
            $this->insertAddress($sellerPdfPage, $sellerCreditmemo->getStore());
            /* Add header to seller pdf page */
            $putOrderId = self::XML_PATH_SALES_PDF_CREDITMEMO_PUT_ORDER_ID;
            $scopeStore = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
            $this->insertOrder(
                $sellerPdfPage, 
                $sellerOrder, 
                $this->_scopeConfig->isSetFlag($putOrderId, $scopeStore, $sellerOrder->getStoreId())
            );
            /* Add creditmemo number on seller pdf page */
            $this->insertDocumentNumber($sellerPdfPage, __('Credit Memo # ') . $sellerCreditmemo->getIncrementId());
            /* draw seller pdf page head */
            $this->_drawPdfPageHeader($sellerPdfPage);
            /* Add body */
            foreach ($sellerCreditmemo->getAllItems() as $sellerCreditmemoItem) {
                if ($sellerCreditmemoItem->getOrderItem()->getParentItem()) {
                    continue;
                }
                /* Draw Seller Order's item */
                $this->_drawItem($sellerCreditmemoItem, $sellerPdfPage, $sellerOrder);
                $sellerPdfPage = end($sellerPdf->pages);
            }
            /* Add sellerCreditmemo totals */
            $this->insertTotals($sellerPdfPage, $sellerCreditmemo);
        }
        $this->_afterGetPdf();
        if ($sellerCreditmemo->getStoreId()) {
            $this->_localeResolver->revert();
        }
        return $sellerPdf;
    }

    /**
     * Create new seller pdf page and assign to PDF object
     *
     * @param  array $pdfSettings
     * @return \Zend_Pdf_Page
     */
    public function newSellerPage(array $pdfSettings = [])
    {
        $sellerPdfPage = parent::newPage($pdfSettings);
        if (!empty($pdfSettings['table_header'])) {
            $this->_drawPdfPageHeader($sellerPdfPage);
        }
        return $sellerPdfPage;
    }

    /**
     * Draw pdf page header for order's product items
     *
     * @param  \Zend_Pdf_Page $sellerPdfPage
     * @return void
     */
    protected function _drawPdfPageHeader(\Zend_Pdf_Page $sellerPdfPage)
    {
        $this->_setFontRegular($sellerPdfPage, 10);
        $sellerPdfPage->setFillColor(new \Zend_Pdf_Color_RGB(0.93, 0.92, 0.92));
        $sellerPdfPage->setLineColor(new \Zend_Pdf_Color_GrayScale(0.5));
        $sellerPdfPage->setLineWidth(0.5);
        $sellerPdfPage->drawRectangle(25, $this->y, 570, $this->y - 30);
        $this->y -= 10;
        $sellerPdfPage->setFillColor(new \Zend_Pdf_Color_RGB(0, 0, 0));

        //seller pdf page product's fields headers
        $rows[0][] = [
            'text' => __('Products'), 
            'feed' => 35
        ];

        $rows[0][] = [
            'text' => __('SKU'),
            'align' => 'right',
            'feed' => 240,
        ];

        $rows[0][] = [
            'text' => __('Price Total (ex)'),
            'align' => 'right',
            'feed' => 350,
        ];

        $rows[0][] = [
            'text' => __('Discount'),
            'align' => 'right',
            'feed' => 400,
        ];

        $rows[0][] = [
            'text' => __('Qty'),
            'align' => 'right',
            'feed' => 450,
        ];

        $rows[0][] = [
            'text' => __('Tax'),
            'align' => 'right',
            'feed' => 490,
        ];

        $rows[0][] = [
            'text' => __('Total (inc)'),
            'align' => 'right',
            'feed' => 560,
        ];

        $rowBlock = ['lines' => $rows, 'height' => 10];

        $this->drawLineBlocks($sellerPdfPage, [$rowBlock], ['table_header' => true]);
        $sellerPdfPage->setFillColor(new \Zend_Pdf_Color_GrayScale(0));
        $this->y -= 20;
    }    

    /**
     * Insert Seller logo to seller pdf page
     *
     * @param \Zend_Pdf_Page &$sellerPdfPage
     * @param null $store
     * @return void
     */
    protected function insertLogo(&$sellerPdfPage, $store = null)
    {  
        $sellerImage = '';
        $sellerImageFlag = 0;
        $sellerId=$this->_getSession()->getCustomerId();
        $collection = $this->_objectManager->create('Webkul\Marketplace\Model\Seller')
                    ->getCollection()
                    ->addFieldToFilter('seller_id', $sellerId);
        foreach ($collection as $row) {
            $sellerImage=$row->getLogoPic();
            if ($sellerImage) {
                $sellerImageFlag = 1;
            }
        }

        if ($sellerImage=='') {
            $sellerImage = $this->_scopeConfig
            ->getValue(
                'sales/identity/logo',
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                $store
            );
            $sellerImageFlag = 0;
        }
        $this->y = $this->y ? $this->y : 815;
        if ($sellerImage) {
            if ($sellerImageFlag == 0) {
                $sellerImagePath = '/sales/store/logo/' . $sellerImage;
            } else {
                $sellerImagePath = '/avatar/' . $sellerImage;
            }
            if ($this->_mediaDirectory->isFile($sellerImagePath)) {
                $sellerImage = \Zend_Pdf_Image::imageWithPath(
                    $this->_mediaDirectory->getAbsolutePath($sellerImagePath)
                );
                $imageTop = 830; //top border of the page
                $imageWidthLimit = 270; //image width half of the page width
                $imageHeightLimit = 270;
                $imageWidth = $sellerImage->getPixelWidth();
                $imageHeight = $sellerImage->getPixelHeight();

                //preserving seller image aspect ratio
                $imageRatio = $imageWidth / $imageHeight;
                if ($imageRatio > 1 && $imageWidth > $imageWidthLimit) {
                    $imageWidth = $imageWidthLimit;
                    $imageHeight = $imageWidth / $imageRatio;
                } elseif ($imageRatio < 1 && $imageHeight > $imageHeightLimit) {
                    $imageHeight = $imageHeightLimit;
                    $imageWidth = $imageHeight * $imageRatio;
                } elseif ($imageRatio == 1 && $imaimageRatiogeHeight > $imageHeightLimit) {
                    $imageHeight = $imageHeightLimit;
                    $imageWidth = $imageWidthLimit;
                }
                $y1Axis = $imageTop - $imageHeight;
                $y2Axis = $imageTop;
                $x1Axis = 25;
                $x2Axis = $x1Axis + $imageWidth;
                //seller image coordinates after transformation seller image are rounded by Zend
                $sellerPdfPage->drawImage($sellerImage, $x1Axis, $y1Axis, $x2Axis, $y2Axis);
                $this->y = $y1Axis - 10;
            }
        }
    }

    /**
     * Insert seller address address and other info to pdf page
     *
     * @param \Zend_Pdf_Page &$sellerPdfPage
     * @param null $store
     * @return void
     */
    protected function insertAddress(&$sellerPdfPage, $store = null)
    {
        $sellerPdfPage->setFillColor(new \Zend_Pdf_Color_GrayScale(0));
        $font = $this->_setFontRegular($sellerPdfPage, 10);
        $sellerPdfPage->setLineWidth(0);
        $this->y = $this->y ? $this->y : 815;
        $imageTop = 815;

        $address = '';
        $sellerId=$this->_getSession()->getCustomerId();
        $collection = $this->_objectManager->create('Webkul\Marketplace\Model\Seller')
                    ->getCollection()
                    ->addFieldToFilter('seller_id', $sellerId);
        foreach ($collection as $row) {
            $address=$row->getOthersInfo();
        }

        if ($address=='') {
            $address = $this->_scopeConfig->getValue(
                'sales/identity/address',
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                $store
            );
        }

        foreach (explode("\n", $address) as $value) {
            if ($value !== '') {
                $value = preg_replace('/<br[^>]*>/i', "\n", $value);
                foreach ($this->string->split($value, 45, true, true) as $_value) {
                    $sellerPdfPage->drawText(
                        trim(strip_tags($_value)),
                        $this->getAlignRight($_value, 130, 440, $font, 10),
                        $imageTop,
                        'UTF-8'
                    );
                    $imageTop -= 10;
                }
            }
        }
        $this->y = $this->y > $imageTop ? $imageTop : $this->y;
    }
}
