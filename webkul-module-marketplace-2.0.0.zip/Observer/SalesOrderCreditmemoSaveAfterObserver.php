<?php
/**
 * Webkul Marketplace SalesOrderCreditmemoSaveAfterObserver Observer.
 *
 * @category    Webkul
 *
 * @package     Webkul_Marketplace
 *
 * @author      Webkul Software
 */
namespace Webkul\Marketplace\Observer;

use Magento\Framework\Event\ObserverInterface;
use Webkul\Marketplace\Model\ResourceModel\Seller\CollectionFactory;

class SalesOrderCreditmemoSaveAfterObserver implements ObserverInterface
{
    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @var CollectionFactory
     */
    protected $_collectionFactory;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_date;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @param \Magento\Framework\ObjectManagerInterface   $objectManager
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $date
     * @param CollectionFactory                           $collectionFactory
     */
    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        CollectionFactory $collectionFactory
    ) 
    {
        $this->_objectManager = $objectManager;
        $this->_customerSession = $customerSession;
        $this->_collectionFactory = $collectionFactory;
        $this->_date = $date;
    }

    /**
     * Sales Order Creditmemo Save After event handler.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $creditmemo = $observer->getCreditmemo();
        $orderId = $creditmemo->getOrderId();
        $order = $creditmemo->getOrder();

        $paymentCode = '';
        $paymentMethod = '';
        if ($order->getPayment()) {
            $paymentCode = $order->getPayment()->getMethod();
        }

        $helper = $this->_objectManager->get('Webkul\Marketplace\Helper\Data');
        // refund calculation check

        $adjustmentPositive = $creditmemo['adjustment_positive'];
        $adjustmentNegative = $creditmemo['adjustment_negative'];
        if ($adjustmentNegative > $adjustmentPositive) {
            $adjustmentNegative = $adjustmentNegative - $adjustmentPositive;
        } else {
            $adjustmentNegative = 0;
        }
        $creditmemoItemsIds = [];
        $creditmemoItemsQty = [];
        $creditmemoItemsPrice = [];
        foreach ($creditmemo->getAllItems() as $item) {
            $creditmemoItemsIds[$item->getOrderItemId()] = $item->getProductId();
            $creditmemoItemsQty[$item->getOrderItemId()] = $item->getQty();
            $creditmemoItemsPrice[$item->getOrderItemId()] = $item->getPrice() * $item->getQty();
        }
        arsort($creditmemoItemsPrice);
        $creditmemoCommissionRateArr = [];
        foreach ($creditmemoItemsPrice as $key => $item) {
            $refundedQty = $creditmemoItemsQty[$key];
            $refundedPrice = $creditmemoItemsPrice[$key];
            $productId = $creditmemoItemsIds[$key];
            $sellerProducts = $this->_objectManager->create(
                'Webkul\Marketplace\Model\Saleslist'
            )->getCollection()
            ->addFieldToFilter(
                'order_id',
                $orderId
            )->addFieldToFilter(
                'order_item_id',
                $key
            )->addFieldToFilter(
                'mageproduct_id',
                $productId
            );
            foreach ($sellerProducts as $sellerProduct) {
                $updatedQty = $sellerProduct['magequantity'] - $refundedQty;
                if ($adjustmentNegative * 1) {
                    if ($adjustmentNegative >= $refundedPrice) {
                        $adjustmentNegative = $adjustmentNegative - $sellerProduct['total_amount'];
                        $updatedPrice = $sellerProduct['total_amount'];
                        $refundedPrice = 0;
                    } else {
                        $refundedPrice = $refundedPrice - $adjustmentNegative;
                        $updatedPrice = $sellerProduct['total_amount'] - $refundedPrice;
                        $adjustmentNegative = 0;
                    }
                } else {
                    $updatedPrice = $sellerProduct['total_amount'] - $refundedPrice;
                }
                if (!($sellerProduct['total_amount'] * 1)) {
                    $sellerProduct['total_amount'] = 1;
                }
                if ($sellerProduct['total_commission'] * 1) {
                    $commissionPercentage = ($sellerProduct['total_commission'] * 100) / $sellerProduct['total_amount'];
                } else {
                    $commissionPercentage = 0;
                }
                if (empty($creditmemoCommissionRateArr[$key])) {
                    $creditmemoCommissionRateArr[$key] = [];
                }
                $creditmemoCommissionRateArr[$key] = $sellerProduct->getData();
                $updatedCommission = ($updatedPrice * $commissionPercentage) / 100;
                $updatedSellerAmount = $updatedPrice - $updatedCommission;

                if ($updatedQty < 0) {
                    $updatedQty = 0;
                }
                if ($updatedPrice < 0) {
                    $updatedPrice = 0;
                }
                if ($updatedSellerAmount < 0) {
                    $updatedSellerAmount = 0;
                }
                if ($updatedCommission < 0) {
                    $updatedCommission = 0;
                }
                if ($refundedQty) {
                    $taxAmount = ($sellerProduct['total_tax'] / $sellerProduct['magequantity']) * $refundedQty;
                    $remainTaxAmount = $sellerProduct['total_tax'] - $taxAmount;
                } else {
                    $taxAmount = 0;
                    $remainTaxAmount = 0;
                }
                if (!$helper->getConfigTaxManage()) {
                    $taxAmount = 0;
                }
                $refundedPrice = $refundedPrice + $taxAmount;
                $partnerRemainSeller = ($sellerProduct->getActualSellerAmount() + $taxAmount) - $updatedSellerAmount;

                $sellerArr[$sellerProduct['seller_id']]['updated_commission'] = $updatedCommission;
                if (!isset($sellerArr[$sellerProduct['seller_id']])) {
                    $mpcodSellerColl[$sellerProduct['seller_id']] = [];
                }
                if ($sellerProduct['cpprostatus'] == 1 && $sellerProduct['paid_status'] == 0) {
                    if (!isset($sellerArr[$sellerProduct['seller_id']]['total_sale'])) {
                        $sellerArr[$sellerProduct['seller_id']]['total_sale'] = 0;
                    }
                    if (!isset($sellerArr[$sellerProduct['seller_id']]['totalremain'])) {
                        $sellerArr[$sellerProduct['seller_id']]['totalremain'] = 0;
                    }
                    if (!isset($sellerArr[$sellerProduct['seller_id']]['totalcommission'])) {
                        $sellerArr[$sellerProduct['seller_id']]['totalcommission'] = 0;
                    }
                    $sellerArr[$sellerProduct['seller_id']]['total_sale'] = 
                    $sellerArr[$sellerProduct['seller_id']]['total_sale'] + $refundedPrice;
                    $sellerArr[$sellerProduct['seller_id']]['totalremain'] = 
                    $sellerArr[$sellerProduct['seller_id']]['totalremain'] + $partnerRemainSeller;
                    $sellerArr[$sellerProduct['seller_id']]['totalcommission'] = 
                    $sellerArr[$sellerProduct['seller_id']]['totalcommission'] + 
                    ($refundedPrice - $partnerRemainSeller);
                } elseif ($sellerProduct['cpprostatus'] == 1 && $sellerProduct['paid_status'] == 1) {
                    if (!isset($sellerArr[$sellerProduct['seller_id']]['total_sale'])) {
                        $sellerArr[$sellerProduct['seller_id']]['total_sale'] = 0;
                    }
                    if (!isset($sellerArr[$sellerProduct['seller_id']]['totalpaid'])) {
                        $sellerArr[$sellerProduct['seller_id']]['totalpaid'] = 0;
                    }
                    if (!isset($sellerArr[$sellerProduct['seller_id']]['totalcommission'])) {
                        $sellerArr[$sellerProduct['seller_id']]['totalcommission'] = 0;
                    }
                    $sellerArr[$sellerProduct['seller_id']]['total_sale'] = 
                    $sellerArr[$sellerProduct['seller_id']]['total_sale'] + $refundedPrice;
                    $sellerArr[$sellerProduct['seller_id']]['totalpaid'] = 
                    $sellerArr[$sellerProduct['seller_id']]['totalpaid'] + $partnerRemainSeller;
                    $sellerArr[$sellerProduct['seller_id']]['totalcommission'] = 
                    $sellerArr[$sellerProduct['seller_id']]['totalcommission'] + 
                    ($refundedPrice - $partnerRemainSeller);
                }
                $sellerProduct->setMagequantity($updatedQty);
                $sellerProduct->setTotalAmount($updatedPrice);
                $sellerProduct->setTotalCommission($updatedCommission);
                $sellerProduct->setActualSellerAmount($updatedSellerAmount);
                $sellerProduct->setTotalTax($remainTaxAmount);
                if ($updatedSellerAmount == 0) {
                    $sellerProduct->setPaidStatus(3);
                    if ($paymentCode == 'mpcashondelivery') {
                        $sellerProduct->setCollectCodStatus(3);
                    }
                }
                $sellerProduct->save();
            }
        }
        $this->_customerSession->setMpCreditmemoCommissionRate(
            $creditmemoCommissionRateArr
        );

        if (!isset($sellerArr)) {
            $sellerArr = [];
        }

        foreach ($sellerArr as $sellerId => $value) {
            $shippingCharges = 0;
            $codCharges = 0;
            $trackingcoll = $this->_objectManager->create(
                'Webkul\Marketplace\Model\Orders'
            )
            ->getCollection()
            ->addFieldToFilter(
                'order_id',
                $orderId
            )
            ->addFieldToFilter(
                'seller_id',
                $sellerId
            );
            foreach ($trackingcoll as $tracking) {
                if ($paymentCode == 'mpcashondelivery') {
                    $codCharges = $tracking->getCodCharges();
                }
                $shippingCharges = $tracking->getShippingCharges();
            }
            if ($shippingCharges >= $creditmemo['shipping_amount']) {
                $shippingCharges = $creditmemo['shipping_amount'];
                $creditmemo['shipping_amount'] = 0;
            } else {
                $creditmemo['shipping_amount'] = $creditmemo['shipping_amount'] - $shippingCharges;
            }
            $collectionverifyread = $this->_objectManager->create(
                'Webkul\Marketplace\Model\Saleperpartner'
            )->getCollection()
            ->addFieldToFilter(
                'seller_id', 
                $sellerId
            );
            foreach ($collectionverifyread as $verifyrow) {
                if (isset($sellerArr[$sellerId]['total_sale'])) {
                    $verifyrow->setTotalSale(
                        $verifyrow->getTotalSale() - (
                            $sellerArr[$sellerId]['total_sale'] + $codCharges + $shippingCharges
                        )
                    );
                }
                if (isset($sellerArr[$sellerId]['totalremain'])) {
                    $verifyrow->setAmountRemain(
                        $verifyrow->getAmountRemain() - (
                            $sellerArr[$sellerId]['totalremain'] + $codCharges + $shippingCharges
                        )
                    );
                }
                if (isset($sellerArr[$sellerId]['totalpaid'])) {
                    $verifyrow->setAmountReceived(
                        $verifyrow->getAmountReceived() - (
                            $sellerArr[$sellerId]['totalpaid'] + $codCharges + $shippingCharges
                        )
                    );
                }
                if (isset($sellerArr[$sellerId]['totalcommission'])) {
                    $verifyrow->setTotalCommission(
                        $verifyrow->getTotalCommission() - $sellerArr[$sellerId]['totalcommission']
                    );
                }
                $verifyrow->save();
            }
        }
    }
}
