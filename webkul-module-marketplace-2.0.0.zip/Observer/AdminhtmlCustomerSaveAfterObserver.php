<?php
/**
 * Webkul Marketplace AdminhtmlCustomerSaveAfterObserver Observer.
 *
 * @category    Webkul
 *
 * @package     Webkul_Marketplace
 *
 * @author      Webkul Software Private Limited
 */
namespace Webkul\Marketplace\Observer;

use Magento\Framework\Event\ObserverInterface;
use Webkul\Marketplace\Model\ResourceModel\Seller\CollectionFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;

class AdminhtmlCustomerSaveAfterObserver implements ObserverInterface
{
    /**
     * File Uploader factory.
     *
     * @var \Magento\MediaStorage\Model\File\UploaderFactory
     */
    protected $_fileUploaderFactory;

    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @var CollectionFactory
     */
    protected $_collectionFactory;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_date;

    /**
     * Store manager.
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $_productRepository;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    private $_messageManager;

    protected $_mediaDirectory;

    /**
     * @param Filesystem                                       $filesystem,
     * @param \Magento\Framework\ObjectManagerInterface        $objectManager,
     * @param \Magento\Framework\Stdlib\DateTime\DateTime      $date,
     * @param \Magento\Framework\Message\ManagerInterface      $messageManager,
     * @param \Magento\Store\Model\StoreManagerInterface       $storeManager,
     * @param \Magento\Catalog\Api\ProductRepositoryInterface  $productRepository,
     * @param CollectionFactory                                $collectionFactory,
     * @param \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory
     */
    public function __construct(
        Filesystem $filesystem,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        CollectionFactory $collectionFactory,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory
    ) 
    {
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(DirectoryList::MEDIA);
        $this->_fileUploaderFactory = $fileUploaderFactory;
        $this->_productRepository = $productRepository;
        $this->_objectManager = $objectManager;
        $this->_messageManager = $messageManager;
        $this->_collectionFactory = $collectionFactory;
        $this->_storeManager = $storeManager;
        $this->_date = $date;
    }

    /**
     * customer register event handler.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $this->moveDirToMediaDir();
        $customer = $observer->getCustomer();
        $customerid = $customer->getId();
        if ($this->isSeller($customerid)) {
            list($data, $errors) = $this->validateprofiledata($observer);
            $fields = $observer->getRequest()->getPostValue();
            $productIds = $observer->getRequest()->getParam('sellerassignproid');
            $unassignproid = $observer->getRequest()->getParam('sellerunassignproid');
            $sellerId = $customerid;
            $partnerType = $observer->getRequest()->getParam('is_seller');
            if ($partnerType == 2) {
                $this->removePartner($sellerId);
                $this->_messageManager->addSuccess(__('You removed the customer from seller.'));

                return $this;
            }
            if ($productIds != '' || $productIds != 0) {
                $this->assignProduct($sellerId, $productIds);
            }
            if ($unassignproid != '' || $unassignproid != 0) {
                $this->unassignProduct($sellerId, $unassignproid);
            }

            $collectionselect = $this->_objectManager->create(
                'Webkul\Marketplace\Model\Saleperpartner'
            )->getCollection()
            ->addFieldToFilter(
                'seller_id', 
                $sellerId
            );
            if ($collectionselect->getSize() == 1) {
                foreach ($collectionselect as $verifyrow) {
                    $autoid = $verifyrow->getEntityId();
                }

                $collectionupdate = $this->_objectManager->get(
                    'Webkul\Marketplace\Model\Saleperpartner'
                )->load($autoid);
                if (!isset($fields['commission'])) {
                    $fields['commission'] = $collectionupdate->getCommissionRate();
                }
                $collectionupdate->setCommissionRate($fields['commission']);
                $collectionupdate->save();
            } else {
                if (!isset($fields['commission'])) {
                    $fields['commission'] = 0;
                }
                $collectioninsert = $this->_objectManager->create(
                    'Webkul\Marketplace\Model\Saleperpartner'
                );
                $collectioninsert->setSellerId($sellerId);
                $collectioninsert->setCommissionRate($fields['commission']);
                $collectioninsert->save();
            }
            if (empty($errors)) {
                $autoId = '';
                $collection = $this->_objectManager->create(
                    'Webkul\Marketplace\Model\Seller'
                )
                ->getCollection()
                ->addFieldToFilter('seller_id', $sellerId);
                foreach ($collection as  $value) {
                    $autoId = $value->getId();
                }
                if (!isset($fields['tw_active'])) {
                    $fields['tw_active'] = 0;
                }
                if (!isset($fields['fb_active'])) {
                    $fields['fb_active'] = 0;
                }
                if (!isset($fields['gplus_active'])) {
                    $fields['gplus_active'] = 0;
                }
                if (!isset($fields['youtube_active'])) {
                    $fields['youtube_active'] = 0;
                }
                if (!isset($fields['vimeo_active'])) {
                    $fields['vimeo_active'] = 0;
                }
                if (!isset($fields['instagram_active'])) {
                    $fields['instagram_active'] = 0;
                }
                if (!isset($fields['pinterest_active'])) {
                    $fields['pinterest_active'] = 0;
                }
                if (!isset($fields['moleskine_active'])) {
                    $fields['moleskine_active'] = 0;
                }
                $value = $this->_objectManager->create(
                    'Webkul\Marketplace\Model\Seller'
                )->load($autoId);
                $value->addData($fields);
                $value->setIsSeller(1);
                $value->setUpdatedAt($this->_date->gmtDate());
                $value->save();
                if (isset($fields['company_description'])) {
                    $fields['company_description'] = str_replace(
                        'script', '', $fields['company_description']
                    );
                    $value->setCompanyDescription($fields['company_description']);
                }

                if (isset($fields['return_policy'])) {
                    $fields['return_policy'] = str_replace(
                        'script', '', $fields['return_policy']
                    );
                    $value->setReturnPolicy($fields['return_policy']);
                }

                if (isset($fields['shipping_policy'])) {
                    $fields['shipping_policy'] = str_replace(
                        'script', '', $fields['shipping_policy']
                    );
                    $value->setShippingPolicy($fields['shipping_policy']);
                }
                if (isset($fields['meta_description'])) {
                    $value->setMetaDescription($fields['meta_description']);
                }
                $target = $this->_mediaDirectory->getAbsolutePath('avatar/');
                try{
                    if (isset($_FILES['banner_pic']) && $_FILES['banner_pic']['name']) {
                        /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
                        $uploader = $this->_fileUploaderFactory->create(['fileId' => 'banner_pic']);
                        /** Allowed extension types */
                        $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
                        /** rename file name if already exists */
                        $uploader->setAllowRenameFiles(true);
                        /** upload file in target folder */
                        $result = $uploader->save($target, $_FILES['banner_pic']['name']);
                        if ($result['file']) {
                            $value->setBannerPic($result['file']);
                        }
                    }
                } catch (\Exception $e) {
                    $this->_messageManager->addError($e->getMessage());
                }
                try{
                    if (isset($_FILES['logo_pic']) && $_FILES['logo_pic']['name']) {
                        /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
                        $uploader = $this->_fileUploaderFactory->create(['fileId' => 'logo_pic']);
                        /** Allowed extension types */
                        $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
                        /** rename file name if already exists */
                        $uploader->setAllowRenameFiles(true);
                        /** upload file in target folder */
                        $result = $uploader->save($target, $_FILES['logo_pic']['name']);
                        if ($result['file']) {
                            $value->setLogoPic($result['file']);
                        }
                    }
                } catch (\Exception $e) {
                    $this->_messageManager->addError($e->getMessage());
                }
                if (array_key_exists('country_pic', $fields)) {
                    $value->setCountryPic($fields['country_pic']);
                }
                $value->save();
            }
        } else {
            $partnerType = $observer->getRequest()->getParam('is_seller');
            $profileurl = $observer->getRequest()->getParam('profileurl');
            if ($partnerType == 1) {
                if ($profileurl != '') {
                    $profileurlcount = $this->_objectManager->create(
                        'Webkul\Marketplace\Model\Seller'
                    )->getCollection();
                    $profileurlcount->addFieldToFilter('shop_url', $profileurl);
                    $sellerProfileId = 0;
                    $sellerProfileUrl = '';
                    $collectionselect = $this->_objectManager->create(
                        'Webkul\Marketplace\Model\Seller'
                    )->getCollection();
                    $collectionselect->addFieldToFilter('seller_id', $customerid);
                    foreach ($collectionselect as $coll) {
                        $sellerProfileId = $coll->getEntityId();
                        $sellerProfileUrl = $coll->getShopUrl();
                    }
                    if ($profileurlcount->getSize() && ($profileurl != $sellerProfileUrl)) {
                        $this->_messageManager->addError(
                            __('This Shop URL already Exists.')
                        );
                    } else {
                        $collection = $this->_objectManager->get(
                            'Webkul\Marketplace\Model\Seller'
                        )->load($sellerProfileId);
                        $collection->setIsSeller(1);
                        $collection->setShopUrl($profileurl);
                        $collection->setSellerId($customerid);
                        $collection->setCreatedAt($this->_date->gmtDate());
                        $collection->setUpdatedAt($this->_date->gmtDate());
                        $collection->save();

                        $helper = $this->_objectManager->get('Webkul\Marketplace\Helper\Data');
                        $adminStoreEmail = $helper->getAdminEmailId();
                        $adminEmail = $adminStoreEmail ? $adminStoreEmail : $helper->getDefaultTransEmailId();
                        $adminUsername = 'Admin';

                        $seller = $this->_objectManager->get(
                            'Magento\Customer\Model\Customer'
                        )->load($customerid);

                        $emailTempVariables['myvar1'] = $seller->getName();
                        $emailTempVariables['myvar2'] = $this->_storeManager->getStore()->getUrl(
                            'customer/account/login'
                        );
                        $senderInfo = [
                            'name' => $adminUsername,
                            'email' => $adminEmail,
                        ];
                        $receiverInfo = [
                            'name' => $seller->getName(),
                            'email' => $seller->getEmail(),
                        ];
                        $this->_objectManager->create('Webkul\Marketplace\Helper\Email')
                        ->sendSellerApproveMail(
                            $emailTempVariables, $senderInfo, $receiverInfo
                        );
                        $this->_messageManager->addSuccess(
                            __('You created the customer as seller.')
                        );
                    }
                } else {
                    $this->_messageManager->addError(
                        __('Enter Shop Name of Customer.')
                    );
                }
            }
        }

        return $this;
    }

    public function isSeller($customerid)
    {
        $sellerStatus = 0;
        $model = $this->_objectManager->create('Webkul\Marketplace\Model\Seller')
                    ->getCollection()
                    ->addFieldToFilter('seller_id', $customerid);
        foreach ($model as $value) {
            $sellerStatus = $value->getIsSeller();
        }

        return $sellerStatus;
    }

    private function validateprofiledata($observer)
    {
        $errors = array();
        $data = array();
        foreach ($observer->getRequest()->getParams() as $code => $value) {
            switch ($code) :
                case 'twitter_id':
                    if (
                        trim($value) != '' && 
                        preg_match('/[\'^£$%&*()}{@#~?><>, |=_+¬-]/', $value)
                    ) {
                        $errors[] = __(
                            'Twitterid cannot contain space and special charecters'
                        );
                    } else {
                        $data[$code] = $value;
                    }
                    break;
                case 'facebook_id':
                    if (
                        trim($value) != '' &&  
                        preg_match('/[\'^£$%&*()}{@#~?><>, |=_+¬-]/', $value)
                    ) {
                        $errors[] = __(
                            'Facebookid cannot contain space and special charecters'
                        );
                    } else {
                        $data[$code] = $value;
                    }
                    break;
            endswitch;
        }

        return array($data, $errors);
    }

    private function removePartner($sellerId)
    {
        $collectionselectdelete = $this->_objectManager->create(
            'Webkul\Marketplace\Model\Seller'
        )->getCollection();
        $collectionselectdelete->addFieldToFilter(
            'seller_id', 
            $sellerId
        );
        foreach ($collectionselectdelete as $delete) {
            $autoid = $delete->getEntityId();
        }
        $collectiondelete = $this->_objectManager->get(
            'Webkul\Marketplace\Model\Seller'
        )->load($autoid);
        $collectiondelete->delete();
        //Set Produt status disabled
        $sellerProduct = $this->_objectManager->create('Webkul\Marketplace\Model\Product')
        ->getCollection()
        ->addFieldToFilter(
            'seller_id', 
            $sellerId
        );

        foreach ($sellerProduct as $productInfo) {
            $allStores = $this->_storeManager->getStores();
            foreach ($allStores as $_eachStoreId => $val) {
                $product = $this->_productRepository->getById(
                    $productInfo->getMageproductId()
                );
                $product->setStatus(
                    \Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_DISABLED
                );
                $this->_productRepository->save($product);
            }

            $productInfo->setStatus(0);
            $productInfo->save();
        }

        $helper = $this->_objectManager->get(
            'Webkul\Marketplace\Helper\Data'
        );
        $adminStoreEmail = $helper->getAdminEmailId();
        $adminEmail = $adminStoreEmail ? $adminStoreEmail : $helper->getDefaultTransEmailId();
        $adminUsername = 'Admin';

        $seller = $this->_objectManager->get(
            'Magento\Customer\Model\Customer'
        )->load($sellerId);

        $emailTempVariables['myvar1'] = $seller->getName();
        $emailTempVariables['myvar2'] = $this->_storeManager->getStore()->getUrl(
            'customer/account/login'
        );
        $senderInfo = [
            'name' => $adminUsername,
            'email' => $adminEmail,
        ];
        $receiverInfo = [
            'name' => $seller->getName(),
            'email' => $seller->getEmail(),
        ];
        $this->_objectManager->create(
            'Webkul\Marketplace\Helper\Email'
        )->sendSellerDisapproveMail(
            $emailTempVariables, 
            $senderInfo, 
            $receiverInfo
        );
    }

    public function assignProduct($sellerId, $productIds)
    {
        $productids = explode(',', $productIds);
        foreach ($productids as $proid) {
            $userid = '';
            $product = $this->_objectManager->get(
                'Magento\Catalog\Model\Product'
            )->load($proid);
            if ($product->getname()) {
                $collection = $this->_objectManager->create(
                    'Webkul\Marketplace\Model\Product'
                )->getCollection()
                ->addFieldToFilter(
                    'mageproduct_id', 
                    $proid
                );
                foreach ($collection as $coll) {
                    $userid = $coll['seller_id'];
                }
                if ($userid) {
                    $this->_messageManager->addError(
                        __('The product is already assigned to other seller.')
                    );
                } else {
                    $collection1 = $this->_objectManager->create(
                        'Webkul\Marketplace\Model\Product'
                    );
                    $collection1->setMageproductId($proid);
                    $collection1->setSellerId($sellerId);
                    $collection1->setStatus($product->getStatus());
                    $collection1->setAdminassign(1);
                    $collection1->setStoreId(array($this->_storeManager->getStore()->getId()));
                    $collection1->setCreatedAt($this->_date->gmtDate());
                    $collection1->setUpdatedAt($this->_date->gmtDate());
                    $collection1->save();
                    $this->_messageManager->addSuccess(
                        __('Products has been successfully assigned to seller.')
                    );
                }
            } else {
                $this->_messageManager->addError(
                    __("Product with id %s doesn't exist.", $proid)
                );
            }
        }
    }

    public function unassignProduct($sellerId, $productIds)
    {
        $productids = explode(',', $productIds);
        foreach ($productids as $proid) {
            $userid = '';
            $product = $this->_objectManager->get(
                'Magento\Catalog\Model\Product'
            )->load($proid);
            if ($product->getname()) {
                $collection = $this->_objectManager->create(
                    'Webkul\Marketplace\Model\Product'
                )->getCollection()
                ->addFieldToFilter(
                    'mageproduct_id', 
                    $proid
                );
                foreach ($collection as $coll) {
                    $coll->delete();
                }
                $this->_messageManager->addSuccess(
                    __('Products has been successfully unassigned to seller.')
                );
            } else {
                $this->_messageManager->addSuccess(
                    __("Product with id %s doesn't exist.", $proid)
                );
            }
        }
    }

    private function moveDirToMediaDir($value = '')
    {
        try {
            /** @var \Magento\Framework\ObjectManagerInterface $objManager */
            $objManager = \Magento\Framework\App\ObjectManager::getInstance();
            /** @var \Magento\Framework\Module\Dir\Reader $reader */
            $reader = $objManager->get('Magento\Framework\Module\Dir\Reader');

            /** @var \Magento\Framework\Filesystem $filesystem */
            $filesystem = $objManager->get('Magento\Framework\Filesystem');

            $mediaAvatarFullPath = $filesystem->getDirectoryRead(
                \Magento\Framework\App\Filesystem\DirectoryList::MEDIA
            )->getAbsolutePath('avatar');
            if (!file_exists($mediaAvatarFullPath)) {
                mkdir($mediaAvatarFullPath, 0777, true);
                $avatarBannerImage = $reader->getModuleDir(
                    '', 'Webkul_Marketplace'
                ).'/view/base/web/images/avatar/banner-image.png';
                copy($avatarBannerImage, $mediaAvatarFullPath.'/banner-image.png');
                $avatarNoImage = $reader->getModuleDir(
                    '', 'Webkul_Marketplace'
                ).'/view/base/web/images/avatar/noimage.png';
                copy($avatarNoImage, $mediaAvatarFullPath.'/noimage.png');
            }

            $mediaMarketplaceFullPath = $filesystem->getDirectoryRead(
                \Magento\Framework\App\Filesystem\DirectoryList::MEDIA
            )->getAbsolutePath('marketplace');
            if (!file_exists($mediaMarketplaceFullPath)) {
                mkdir($mediaMarketplaceFullPath, 0777, true);
            }

            $mediaMarketplaceBannerFullPath = $filesystem->getDirectoryRead(
                \Magento\Framework\App\Filesystem\DirectoryList::MEDIA
            )->getAbsolutePath('marketplace/banner');
            if (!file_exists($mediaMarketplaceBannerFullPath)) {
                mkdir($mediaMarketplaceBannerFullPath, 0777, true);
                $marketplaceBannerImage = $reader->getModuleDir(
                    '', 'Webkul_Marketplace'
                ).'/view/base/web/images/marketplace/banner/sell-page-banner.png';
                copy($marketplaceBannerImage, $mediaMarketplaceBannerFullPath.'/sell-page-banner.png');
            }

            $mediaMarketplaceIconFullPath = $filesystem->getDirectoryRead(
                \Magento\Framework\App\Filesystem\DirectoryList::MEDIA
            )->getAbsolutePath('marketplace/icon');
            if (!file_exists($mediaMarketplaceIconFullPath)) {
                mkdir($mediaMarketplaceIconFullPath, 0777, true);
                $icon1BannerImage = $reader->getModuleDir(
                    '', 'Webkul_Marketplace'
                ).'/view/base/web/images/marketplace/icon/icon-add-products.png';
                copy($icon1BannerImage, $mediaMarketplaceIconFullPath.'/icon-add-products.png');

                $icon2BannerImage = $reader->getModuleDir(
                    '', 'Webkul_Marketplace'
                ).'/view/base/web/images/marketplace/icon/icon-collect-revenues.png';
                copy($icon2BannerImage, $mediaMarketplaceIconFullPath.'/icon-collect-revenues.png');

                $icon3BannerImage = $reader->getModuleDir(
                    '', 'Webkul_Marketplace'
                ).'/view/base/web/images/marketplace/icon/icon-register-yourself.png';
                copy($icon3BannerImage, $mediaMarketplaceIconFullPath.'/icon-register-yourself.png');

                $icon4BannerImage = $reader->getModuleDir(
                    '', 'Webkul_Marketplace'
                ).'/view/base/web/images/marketplace/icon/icon-start-selling.png';
                copy($icon4BannerImage, $mediaMarketplaceIconFullPath.'/icon-start-selling.png');
            }

            $mediaPlaceholderFullPath = $filesystem->getDirectoryRead(
                \Magento\Framework\App\Filesystem\DirectoryList::MEDIA
            )->getAbsolutePath('placeholder');
            if (!file_exists($mediaPlaceholderFullPath)) {
                mkdir($mediaPlaceholderFullPath, 0777, true);
                $placeholderImage = $reader->getModuleDir(
                    '', 'Webkul_Marketplace'
                ).'/view/base/web/images/placeholder/image.jpg';
                copy($placeholderImage, $mediaPlaceholderFullPath.'/image.jpg');
            }
        } catch (\Exception $e) {
            $this->_messageManager->addError($e->getMessage());
        }
    }
}
