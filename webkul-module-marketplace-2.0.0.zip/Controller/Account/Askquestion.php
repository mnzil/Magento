<?php
/**
 * Webkul Marketplace Askquestion Controller.
 *
 * @category    Webkul
 *
 * @package     Webkul_Marketplace
 *
 * @author      Webkul Software Private Limited
 */
namespace Webkul\Marketplace\Controller\Account;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Customer\Model\Session;

class Askquestion extends \Magento\Customer\Controller\AbstractAccount
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @param Context     $context
     * @param Session     $customerSession
     */
    public function __construct(
        Context $context,
        Session $customerSession
    ) 
    {
        $this->_customerSession = $customerSession;
        parent::__construct($context);
    }

    /**
     * Ask Query to seller action.
     *
     * @return \Magento\Framework\App\ResponseInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getParams();

        $helper = $this->_objectManager->get('Webkul\Marketplace\Helper\Data');

        $sellerName = $this->_customerSession->getCustomer()->getName();
        $sellerEmail = $this->_customerSession->getCustomer()->getEmail();

        $adminStoremail = $helper->getAdminEmailId();
        $adminEmail = $adminStoremail ? $adminStoremail : $helper->getDefaultTransEmailId();
        $adminUsername = 'Admin';

        $emailTemplateVariables = array();
        $senderInfo = array();
        $receiverInfo = array();
        $emailTemplateVariables['myvar1'] = $adminUsername;
        $emailTemplateVariables['myvar2'] = $sellerName;
        $emailTemplateVariables['subject'] = $data['subject'];
        $emailTemplateVariables['myvar3'] = $data['ask'];
        $senderInfo = [
            'name' => $sellerName,
            'email' => $sellerEmail,
        ];
        $receiverInfo = [
            'name' => $adminUsername,
            'email' => $adminEmail,
        ];
        $this->_objectManager
        ->create('Webkul\Marketplace\Helper\Email')
        ->askQueryAdminEmail($emailTemplateVariables, $senderInfo, $receiverInfo);
        $this->getResponse()->representJson(
            $this->_objectManager->get('Magento\Framework\Json\Helper\Data')
            ->jsonEncode('true')
        );
    }
}
