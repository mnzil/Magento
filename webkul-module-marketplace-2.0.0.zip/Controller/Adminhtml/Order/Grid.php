<?php
namespace Webkul\Marketplace\Controller\Adminhtml\Order;

class Grid extends Index
{
    /**
     * set page data
     *
     * @return $this
     */
    public function setPageData()
    {
        return $this;
    }
}
