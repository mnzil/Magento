<?php
/**
 * Webkul Marketplace Order Invoice View Controller.
 *
 * @category    Webkul
 *
 * @package     Webkul_Marketplace
 *
 * @author      Webkul Software Private Limited
 */
namespace Webkul\Marketplace\Controller\Order\Invoice;

class View extends \Webkul\Marketplace\Controller\Order
{
    /**
     * Webkul Marketplace Order Invoice View Action.
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        if ($invoice = $this->_initInvoice()) {
            /** @var \Magento\Framework\View\Result\Page $resultPage */
            $resultPage = $this->_resultPageFactory->create();
            $resultPage->getConfig()->getTitle()->set(
                __('Order #%1', $invoice->getOrder()->getRealOrderId())
            );
            return $resultPage;
        } else {
            return $this->resultRedirectFactory->create()->setPath(
                '*/*/history', 
                [
                    '_secure'=>$this->getRequest()->isSecure()
                ]
            );
        }
    }
}
