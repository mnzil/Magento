<?php
/**
 * Webkul Marketplace Sold Product Order Details Controller.
 *
 * @category    Webkul
 *
 * @package     Webkul_Marketplace
 *
 * @author      Webkul Software Private Limited
 */
namespace Webkul\Marketplace\Controller\Order;

class Salesdetail extends \Webkul\Marketplace\Controller\Order
{
    /**
     * Webkul Marketplace Sold Product Order Details page.
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $helper = $this->_objectManager->create('Webkul\Marketplace\Helper\Data');
        $isPartner = $helper->isSeller();
        if ($isPartner == 1) {
            /* @var \Magento\Framework\View\Result\Page $resultPage */

            $productId = (int) $this->getRequest()->getParam('id');

            $resultPage = $this->resultPageFactory->create();
            $resultPage->getConfig()->getTitle()->set(
                __(
                    'Order Details of Product : %1',
                    $this->_objectManager->create(
                        'Magento\Catalog\Model\Product'
                    )->load($productId)->getName()
                )
            );

            return $resultPage;
        } else {
            return $this->resultRedirectFactory->create()->setPath(
                '*/*/becomeseller',
                ['_secure' => $this->getRequest()->isSecure()]
            );
        }
    }
}
