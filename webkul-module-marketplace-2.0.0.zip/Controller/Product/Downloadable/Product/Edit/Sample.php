<?php
namespace Webkul\Marketplace\Controller\Product\Downloadable\Product\Edit;

use Magento\Downloadable\Helper\Download as DownloadableHelper;

class Sample extends \Webkul\Marketplace\Controller\Product\Edit
{
    /**
     * Seller Downloadable Product Sample action
     *
     * @return void
     */
    public function execute()
    {
        $helper = $this->_objectManager->create('Webkul\Marketplace\Helper\Data');
        $isPartner = $helper->isSeller();
        if ($isPartner == 1) {
            try {
                $sampleId = $this->getRequest()->getParam('id', 0);
                $productSample = $this->_objectManager->create(
                    'Magento\Downloadable\Model\Sample'
                )->load($sampleId);
                $mageProductId = $productSample->getProductId();
                $helper = $this->_objectManager->get('Webkul\Marketplace\Helper\Data');
                $isPartner = $helper->isSeller();
                $flag = false;
                if ($isPartner == 1) {
                    $rightseller = $helper->isRightSeller($mageProductId);
                    if ($rightseller == 1) {
                        $flag = true;
                    }
                }
                if ($productSample->getId() && $flag) {
                    $sampleTypeUrl = DownloadableHelper::LINK_TYPE_URL;
                    $sampleTypeFile = DownloadableHelper::LINK_TYPE_FILE;
                    $sampleUrl = '';
                    $sampleType = '';
                    if ($productSample->getSampleType() == $sampleTypeUrl) {
                        $sampleUrl = $productSample->getSampleUrl();
                        $sampleType = $sampleTypeUrl;
                    } elseif ($productSample->getSampleType() == $sampleTypeFile) {
                        $sampleUrl = $this->_objectManager->get(
                            'Magento\Downloadable\Helper\File'
                        )->getFilePath(
                            $this->_objectManager->get('Magento\Downloadable\Model\Sample')->getBasePath(),
                            $productSample->getSampleFile()
                        );
                        $sampleType = $sampleTypeFile;
                    }
                    $downloadableHelper = $this->_objectManager->get('Magento\Downloadable\Helper\Download');
                    $downloadableHelper->setResource($sampleUrl, $sampleType);
                    $this->getResponse()
                        ->setHttpResponseCode(200)
                        ->setHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0', true)
                        ->setHeader('Pragma', 'public', true)
                        ->setHeader('Content-type', $downloadableHelper->getContentType(), true);
                    if ($downloadableHelper->getFileSize()) {
                        $this->getResponse()->setHeader('Content-Length', $downloadableHelper->getFileSize());
                    }
                    if ($contentDisposition = $downloadableHelper->getContentDisposition()) {
                        $this->getResponse()->setHeader(
                            'Content-Disposition', 
                            $contentDisposition . '; filename=' . $downloadableHelper->getFilename()
                        );
                    }
                    $this->getResponse()->clearBody();
                    $this->getResponse()->sendHeaders();
                    $downloadableHelper->output();
                } else {
                    $this->messageManager->addError(__('You are not authorized to perform this action.'));
                }     
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            }
        } else {
            return $this->resultRedirectFactory->create()->setPath(
                '*/*/becomeseller',
                ['_secure' => $this->getRequest()->isSecure()]
            );
        }
    }
}
